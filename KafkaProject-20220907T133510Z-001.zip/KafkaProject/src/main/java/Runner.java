public class Runner {
    public static void main(String[] args) {
        SampleProd sampleProd = new SampleProd();
    }
}

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

public class SampleProd {
    /**
     * Connect to Kafka server and send the message
     */
    public SampleProd() {
        /**
         * bootstrap serves; This is Address of kafka server
         * Creating a Properties object for kafka producer
         */
//        Properties properties = new Properties();
//        properties.put("bootstrap.servers", "localhost:9092");
//        properties.put("key.serializer","org.apache.kafka.common.serialization.StringSerializer");
//        properties.put("value.serializer","org.apache.kafka.common.serialization.StringSerializer");
//
//        ProducerRecord producerRecord = new ProducerRecord("channel","name","first-kafka");
//        KafkaProducer kafkaProducer = new KafkaProducer(properties);
//        kafkaProducer.send(producerRecord);
//        kafkaProducer.close();
        /**
         * Creating a Properties object for kafka Producer
         */
        Properties properties = new Properties();
//        properties.setProperty("bootstrap.servers","127.0.0.1:9092");// instead of this implementation we can user below provided,
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"127.0.0.1:9092");
        //get key serializer
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        //get value serializer
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
        //boostrap.servers

        /**
         * Create the Kafka Producer
         */
        final KafkaProducer<String,String> kafkaProducer = new KafkaProducer<String, String>(properties);

        /**
         * Creating the producer records
         */
        ProducerRecord<String,String>  producerRecord = new ProducerRecord<>("channel","key1","value1");


        /**
         *  Send Data - Asynchronous
         *  send method is an overloaded method.
         */
        kafkaProducer.send(producerRecord);

        /**
         * Flush the producer - wrights any pending records producer might be having into kafka topic
         */
        kafkaProducer.flush();

        /**
         * Close the Producer
         */
        kafkaProducer.close();
    }
}
